
Incomplete part:
1. 1st Bonus question of part 2c.

Team members:
1.Bhoopalsinh Musale	002269332
2.Sara Eskandarirad	002279327