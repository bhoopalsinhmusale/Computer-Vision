
Completed all parts.

Team members:
1.Bhoopalsinh Musale	002269332
2.Sara Eskandarirad	002279327