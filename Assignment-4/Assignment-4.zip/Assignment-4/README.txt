
Incomplete part:
1. Part-3 half done.

Team members:
1.Bhoopalsinh Musale	002269332
2.Sara Eskandarirad	002279327